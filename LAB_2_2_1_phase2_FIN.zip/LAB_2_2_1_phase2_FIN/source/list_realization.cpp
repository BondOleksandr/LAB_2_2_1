#include "list_realization.hpp"

ListRealization::~ListRealization() = default;
