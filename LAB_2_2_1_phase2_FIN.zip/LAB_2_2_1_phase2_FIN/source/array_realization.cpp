#include "array_realization.hpp"

ArrayRealization::~ArrayRealization() = default;