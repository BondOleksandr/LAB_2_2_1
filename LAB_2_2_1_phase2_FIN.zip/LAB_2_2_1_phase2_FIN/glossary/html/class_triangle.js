var class_triangle =
[
    [ "Triangle", "class_triangle.html#ad6736ceb2c5266d5654dc3e4dd6f5970", null ],
    [ "printInfo", "class_triangle.html#aa395ac08f04e6f7f2b8afed1f4e7b8cb", null ],
    [ "shift", "class_triangle.html#a21cb3c6989413f6ad4fdba6a91d8ac4e", null ]
];