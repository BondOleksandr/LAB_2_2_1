var struct_matrix___node =
[
    [ "clmn", "struct_matrix___node.html#a9b9037a73c351d4ad720d60e24a33580", null ],
    [ "next", "struct_matrix___node.html#a31f9d1b64772a925dd7047b4771f28fb", null ],
    [ "row", "struct_matrix___node.html#ada537e41d07dd90ecbb25bbaed16f790", null ],
    [ "val", "struct_matrix___node.html#ae105f0e289fd350215faa55d794c37de", null ]
];