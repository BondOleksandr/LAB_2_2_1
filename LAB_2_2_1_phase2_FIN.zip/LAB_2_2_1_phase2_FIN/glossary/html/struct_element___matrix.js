var struct_element___matrix =
[
    [ "clmn", "struct_element___matrix.html#ada7ce4afd9a0004222c2198cf3aee7b3", null ],
    [ "row", "struct_element___matrix.html#ae42a96cd32bdc14c26b1ca2ed3c787db", null ],
    [ "val", "struct_element___matrix.html#a3139a2496337d03852e875f29501d580", null ]
];