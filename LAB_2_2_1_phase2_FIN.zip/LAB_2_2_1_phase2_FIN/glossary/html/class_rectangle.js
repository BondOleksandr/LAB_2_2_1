var class_rectangle =
[
    [ "Rectangle", "class_rectangle.html#aea70aa224eca64db573afb40bc21ab88", null ],
    [ "printInfo", "class_rectangle.html#afa6bd15c741c1f4f9ff650aeb02d1c1a", null ],
    [ "shift", "class_rectangle.html#ac44ddad8a78674fb144d48ab35729895", null ]
];