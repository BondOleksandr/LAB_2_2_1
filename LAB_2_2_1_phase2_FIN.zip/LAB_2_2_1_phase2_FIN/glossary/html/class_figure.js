var class_figure =
[
    [ "~Figure", "class_figure.html#a7d1d880545c2a5a8ccde709903aa783c", null ],
    [ "printFigureInfo", "class_figure.html#a0b826d5c11ab53190611e17fe3f5a381", null ],
    [ "printInfo", "class_figure.html#a605696a6d49001d966516839e9691ba1", null ],
    [ "shift", "class_figure.html#a9f135622fc42ccb6d82a52bc812b4c41", null ]
];