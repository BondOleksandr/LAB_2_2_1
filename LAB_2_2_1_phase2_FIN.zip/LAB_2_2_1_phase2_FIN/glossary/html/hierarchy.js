var hierarchy =
[
    [ "ArrayRealization", "class_array_realization.html", [
      [ "ArrMatrix", "class_arr_matrix.html", null ],
      [ "ArrVector", "class_arr_vector.html", null ]
    ] ],
    [ "Element_Matrix", "struct_element___matrix.html", null ],
    [ "Element_Vector", "struct_element___vector.html", null ],
    [ "Figure", "class_figure.html", [
      [ "Circle", "class_circle.html", null ],
      [ "Rectangle", "class_rectangle.html", null ],
      [ "Triangle", "class_triangle.html", null ]
    ] ],
    [ "Line", "class_line.html", null ],
    [ "ListRealization", "class_list_realization.html", [
      [ "ListMatrix", "class_list_matrix.html", null ],
      [ "ListVector", "class_list_vector.html", null ]
    ] ],
    [ "Matrix_Node", "struct_matrix___node.html", null ],
    [ "Point", "class_point.html", null ],
    [ "Vector_Node", "struct_vector___node.html", null ]
];