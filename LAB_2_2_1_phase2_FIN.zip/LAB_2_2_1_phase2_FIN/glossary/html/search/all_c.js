var searchData=
[
  ['shift_0',['shift',['../class_circle.html#aed8b55a5b19836bc67a5260cc90bdb72',1,'Circle::shift()'],['../class_figure.html#a9f135622fc42ccb6d82a52bc812b4c41',1,'Figure::shift()'],['../class_point.html#a6943e331d9660873427162e84eb12ef8',1,'Point::shift()'],['../class_rectangle.html#ac44ddad8a78674fb144d48ab35729895',1,'Rectangle::shift()'],['../class_triangle.html#a21cb3c6989413f6ad4fdba6a91d8ac4e',1,'Triangle::shift()']]],
  ['summ_1',['Summ',['../class_list_matrix.html#a47399bb3087741f5cfcafd1b0d32afc8',1,'ListMatrix']]]
];
