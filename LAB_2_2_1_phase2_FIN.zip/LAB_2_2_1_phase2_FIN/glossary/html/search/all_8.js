var searchData=
[
  ['next_0',['next',['../struct_matrix___node.html#a31f9d1b64772a925dd7047b4771f28fb',1,'Matrix_Node::next'],['../struct_vector___node.html#a4c62d904afa26a699d4fbf979dd45e42',1,'Vector_Node::next']]]
];
