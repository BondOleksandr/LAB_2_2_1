var class_point =
[
    [ "Point", "class_point.html#a78b55e8d5466bb8c2cf60fa55f2562ff", null ],
    [ "shift", "class_point.html#a6943e331d9660873427162e84eb12ef8", null ]
];