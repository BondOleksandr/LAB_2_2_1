#include "all_matrix&vector.hpp"

MatrixBase::~MatrixBase() = default;
